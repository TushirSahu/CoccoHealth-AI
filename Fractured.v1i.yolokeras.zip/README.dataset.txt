# Fractured > 2023-10-16 9:37pm
https://universe.roboflow.com/tushir-sahu-cp5gk/fractured-5irsj

Provided by a Roboflow user
License: CC BY 4.0

